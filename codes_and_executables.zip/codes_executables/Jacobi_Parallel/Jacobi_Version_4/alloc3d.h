#ifndef __ALLOC_3D_2
#define __ALLOC_3D_2

double ***d_malloc_3d(int m, int n, int k);

#endif /* __ALLOC_3D_2 */
